import React, { Component } from 'react'
import  './AboutUs.css'
export default class AboutUs extends Component {
  render() {
    return (
      <div className='about-us-cont'>
        <div className="heading-cont"><h6>About Us</h6></div>
        <div className="sub-head"><h5>We are specialzed in medical Diagonstics </h5></div>
        <div className="content">
        <p>
        Shri Ganesh Eye Hospital has been established in 2018 with a Vision to provide dedicated and quality eye care to patients.</p>

<p>A comprehensive eye facility with the use of latest technological inventions like 2.2 mm Suturless Phaco Emulsification Techniques is being provided here. It’s only kind of infrastructure in Jharkhand which provides enhanced patient care with homely treatment.</p>

<p>Established by Dr. Amit Kr. Jayswal, MS(Eye),FRCS(I) Glasgow with an wide experience of Cataract & Refractive Surgery at SGVEH Raipur, Medical Retina at Aravind Eye Hospital Pondicherry, Advanced Phaco Emulsification Training at Susrut Eye Hospital Kolkata. He was also a Consultant at Shreshtha Netra Chikitsalaya Ranchi. Dr. Amit has performed above 10000 Cataract Surgeries.</p>

<p>With such a wide gamut of experience, the team at Shri Ganesh Eye Hospital is dedicated to provide quality care as well as the most advanced eye care with personalised attention.</p>
        </div>
        
      </div>
    )
  }
}
