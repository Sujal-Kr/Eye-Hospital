import a1 from '../Assets/a1.jpg'
import a2 from '../Assets/a2.jpg'
import a3 from '../Assets/a3.jpg'
import a4 from '../Assets/a4.jpg'
import a5 from '../Assets/a5.jpg'
export const achImages=[a1, a2, a3, a4, a5]