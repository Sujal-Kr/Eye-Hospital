import image1 from '../Assets/1.jpg'
import image2 from '../Assets/2.jpg'
import image3 from '../Assets/3.jpg'
import image4 from '../Assets/4.jpg'
// import image5 from '../Assets/5.jpg'
// import image6 from '../Assets/6.jpg'
// import image7 from '../Assets/7.jpg'
// import image8 from '../Assets/8.jpg'
export const images=[image1,image2,image3,image4,] 