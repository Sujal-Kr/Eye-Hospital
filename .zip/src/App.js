
import './App.css';
import Home from './Components/home/Home';
function App() {
  return (
   <div>
    <Home/>
   </div>
  );
}

export default App;
